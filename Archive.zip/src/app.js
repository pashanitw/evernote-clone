import ReactDom from "react-dom";
import store from "./reducers"
import {Provider,connect} from "react-redux"
import React from "react"
import {Component} from "react";


const Header = ()=> {
    return <header className="storeHeader">
        <a href="/sams/homepage.jsp?xid=hdr_logo" className="sc-sprite sc-sprite-Logo samsClubLogo"  title="SamsClub.com Home">SamsClub.com Home</a>
    </header>
}
const Section = ()=> {
    return <section className="mainContainer">

        <h1 className="regpagetitle">Fractional Membership</h1>
        <p style={{height:200}}>
            Not quite sure if you want to commit yet?
            Try our membership for just $5.
            If you decide to continue being a member,
            we'll give you a $5 gift card as a thank you.
        </p>
    </section>
};
const Login=({renderForgot})=>{
    var user,password
    return <div>
        <div className="form-group">
            <label>User Name</label>
            <input type="text"
                className="form-control"
                ref={node=>user=node}/>
        </div>
        <div className="form-group">
            <label>Password</label>
            <input type="text"
                className="form-control"
                ref={node=>password=node}/>
        </div>
            <a class="btn btn-primary">Login</a>
        <div className="form-group">
            <a onClick={renderForgot}>Forgot password</a>
        </div>
    </div>
}
const Forgot=()=>{
    return <div>
        <div className="form-group">
            <label>Enter Ur Email to send password</label>
            <input type="text"
                className="form-control"/>
        </div>
    </div>
}
const Footer = ()=> {
    return <footer id="footerSection">
        <div className="FooterBottmWrapper cc_csrText">Have Questions? One of our associates will be happy to help you. Call us at 1-888-746-7726.</div>
        <div className="FooterBottmWrapper fixboth">
            <ul className="tnc fixboth">
                <li>
                    <a href="help/Site_Directory.jsp?xid=ftr:site-directory">Site Directory</a>
                </li>
                <li>
                    <a href="pagedetails/content.jsp?pageName=privacyPolicy&amp;xid=ftr:our-privacy-policy">Our Privacy Policy</a>
                </li>
                <li>
                    <a href="pagedetails/content.jsp?pageName=termsandconditions&amp;xid=ftr:terms-and-condition">Terms and Condition</a>
                </li>
                <li>
                    <a title="Facebook" target="_blank" href="http://www.facebook.com/samsclub?xid=ftr:facebook" className="sc-sprite-facebook">Facebook</a>
                </li>
                <li>
                    <a title="Pinterest" target="_blank" href="http://pinterest.com/samsclub/?xid=ftr:pinterest" className="sc-sprite-pinterest">Pinterest</a>
                </li>
                <li>
                    <a title="Twitter" target="_blank" href="https://twitter.com/samsclub?xid=ftr:twitter" className="sc-sprite-twitter">Twitter</a>
                </li>
                <li>
                    <a title="Google+" target="_blank" href="https://plus.google.com/+samsclub?xid=ftr:google" className="sc-sprite-google">Google+</a>
                </li>
            </ul>
            <div className="copyright">&copy; 2000-2015, Sam's West, Inc. All rights reserved</div>
        </div>
    </footer>

};
class Main extends Component {
    constructor(props,context){
        super(props,context);
        this.state={
            isLogin:true
        }
    }
    renderForgot(){
        this.setState({
            isLogin:false
        })
    }
    renderField(){
        if(this.state.isLogin){
            return <Login renderForgot={this.renderForgot.bind(this)}/>
        }
        else{
            return <Forgot/>
        }
    }
    render(){
        return <div>
            <Header></Header>
            <Section></Section>
        {this.renderField()}
            <Footer></Footer>
        </div>
    }

};
const MainApp = ()=> {
    return <Provider store={store}>
        <Main/>
    </Provider>
};

ReactDom.render(<MainApp/>, document.getElementById('app'))